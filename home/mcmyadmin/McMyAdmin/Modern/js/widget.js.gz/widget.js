document.write("<div style=\"width:468px;height:60px;background:#5F8EAE;display:block;color:white;font-family:Verdana, sans-serif;\"> \
	<a href=\"http://mcmyadmin.com/\"><img src=\"http://mcmyadmin.com/Images/LogoTiny.png\" style=\"padding:4px 8px 4px 8px;float:left;\" alt=\"McMyAdmin Logo\"/></a> \
	<span class=\"MCMAWDG_TITLE\" style=\"float:left;margin-top:8px;font-weight:bold;font-size:12pt;z-index:2;\">My Minecraft Server&nbsp;&nbsp;<span style=\"font-size:10pt\">localhost:25565</span><br/> \
		<span class=\"MCMAWDG_SUB\"style=\"font-size:10pt;font-weight:normal;\">Offline - 0/8 Players</span> \
	</span>	\
	<span class=\"MCMA_NOTICE\" style=\"float:right;margin:0 4px 2px 0;font-size:7pt;z-index:1;\">Powered by <a href=\"http://mcmyadmin.com/\" style=\"color:white;\">McMyAdmin Personal</a></span></div>");